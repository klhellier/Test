export const CLONE_TOP = 'top';
export const CLONE_BOTTOM = 'bottom';
export const CLONE_LEFT = 'left';
export const CLONE_TOP_LEFT_CORNER = 'top_left_corner';
export const CLONE_BOTTOM_LEFT_CORNER = 'bottom_left_corner';
export const CLONE_TYPES = [
  CLONE_TOP,
  CLONE_BOTTOM,
  CLONE_LEFT,
  CLONE_TOP_LEFT_CORNER,
  CLONE_BOTTOM_LEFT_CORNER,
];
