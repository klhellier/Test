export {
  PLUGIN_KEY,
  PLUGIN_PRIORITY,
  DragToScroll,
} from './dragToScroll';
