export const KEY = '---------';

/**
 * @returns {object}
 */
export default function separatorItem() {
  return {
    name: KEY
  };
}
