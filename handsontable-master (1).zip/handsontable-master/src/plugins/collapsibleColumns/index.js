export {
  PLUGIN_KEY,
  PLUGIN_PRIORITY,
  CollapsibleColumns,
} from './collapsibleColumns';
