export {
  PLUGIN_KEY,
  PLUGIN_PRIORITY,
  CopyPaste,
} from './copyPaste';
