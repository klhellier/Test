export {
  CELL_TYPE,
  HandsontableCellType,
} from './handsontableType';
