import Handsontable from './handsontable'

export default Handsontable;
